//cohesion
package com.godrejcapital.smsapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

/**
 * @author sandeep
 * @since 1.0
 * @version 2.0
 */
/*
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Student implements Comparable<Student> {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int rollNumber;
    private String name;
    private int score;

    public void display() {
        System.out.println(this.rollNumber);
        System.out.println(this.name);
        System.out.println(this.score);
    }

    @Override
    public int compareTo(Student o) {
        return this.name.compareTo(o.name);
    }
}