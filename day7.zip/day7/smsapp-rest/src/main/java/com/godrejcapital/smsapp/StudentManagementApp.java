package com.godrejcapital.smsapp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.ArrayList;

//import java.lang.*;	//already present
@SpringBootApplication
@EnableAsync
public class StudentManagementApp{
	public static void main(String[] args)
	{

		ApplicationContext container = SpringApplication.run(StudentManagementApp.class);
	}

}