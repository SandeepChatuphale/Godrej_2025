package com.godrejcapital.smsapp.service;

import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;

import java.rmi.StubNotFoundException;
import java.util.List;

public interface StudentService {

    Student registerStudent(Student s);
    Student searchByRollNumber(int rollNumber) throws StudentNotFoundException;
    void deleteByRollNumber(int rollNumber)throws StudentNotFoundException;
    Student updateStudent(int rollNumber,Student existingStudent) throws StudentNotFoundException;
    List<Student> serachAll();
}
