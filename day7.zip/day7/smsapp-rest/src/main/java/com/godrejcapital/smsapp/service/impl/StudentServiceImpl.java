package com.godrejcapital.smsapp.service.impl;

import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.service.EmailService;
import com.godrejcapital.smsapp.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.rmi.StubNotFoundException;
import java.util.List;
import java.util.Optional;

//responsible for performing business logic
//get the data by invoking dao layer methods when needed
@Service("myservice")
@Scope("singleton")
public class StudentServiceImpl implements StudentService {

    @Autowired
    private EmailService emailService;

    //DI
    @Autowired
    private StudentDao dao;

    @Override
    public Student registerStudent(Student s) {

        System.out.println("Sending email " + Thread.currentThread().getName());
        //send email
        emailService.sendEmail();
        System.out.println("email sent");
        return this.dao.save(s);
    }

    @Override
    public Student searchByRollNumber(int rollNumber) throws StudentNotFoundException {
        Optional<Student> o = this.dao.findById(rollNumber);

        if(o.isPresent())
            return o.get();

        throw new StudentNotFoundException(rollNumber);
    }

    @Override
    public void deleteByRollNumber(int rollNumber) throws StudentNotFoundException {
        searchByRollNumber(rollNumber);
        this.dao.deleteById(rollNumber);
    }

    @Override
    public Student updateStudent(int rollNumber, Student existingStudent) throws StudentNotFoundException {
        Student foundStudent = searchByRollNumber(rollNumber);
        foundStudent.setName(existingStudent.getName());
        foundStudent.setScore(existingStudent.getScore());
        this.dao.save(foundStudent);
        return foundStudent;
    }

    @Override
    public List<Student> serachAll() {
        return List.of();
    }


}
