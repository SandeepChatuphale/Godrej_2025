package com.godrejcapital.smsapp.service.impl;

import com.godrejcapital.smsapp.service.EmailService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService {

    //this is complex and long-running process
    //we want to do it in async fashion
    @Override
    @Async
    public void sendEmail() {

        System.out.println(this.getClass());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("email sent in " + Thread.currentThread().getName());
        return;
    }
}
