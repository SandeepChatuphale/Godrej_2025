package com.godrejcapital.smsapp.rest.controller;

import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
public class StudentRestController {



    @Qualifier("myservice")
    @Autowired
    private StudentService service;

    //http://localhost:8080/students
    @GetMapping("/students")
    public List<Student> searchAll(){
        System.out.println("searchAll");
        return service.
    }

    //http://localhost:8080/students?sort
    @GetMapping(value = "/students",params = "sort")
    public List<Student> sortAll(){
        System.out.println("sort");
        Collections.sort(dao.findAll());
        return dao.findAll();
    }



    @ResponseStatus(code= HttpStatus.CREATED)
    @PostMapping("/student")
    public Student createStudent(@RequestBody Student s){
        return service.registerStudent(s);
    }

    @ResponseStatus(code=HttpStatus.NO_CONTENT)
    //path variable
    @DeleteMapping("/student/{rollNumber}")
    public void removeStudent(int rollNumber) throws StudentNotFoundException {
        this.dao.deleteById(rollNumber);
    }

    @GetMapping("/student/{rollNumber}")
   public  Student searchByRollNumber(@PathVariable int rollNumber) throws StudentNotFoundException {
    return this.dao.findById(rollNumber).get();
    }

}
