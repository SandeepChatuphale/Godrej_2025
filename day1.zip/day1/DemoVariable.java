public class DemoVariable
{

public static void main(String[] args)
	{
	//syntax:- data_type <nameOfVariable>;
	//8 primitive data types 
		
	//byte,short,int,long

	int age;//local variable to main method
		//local variable MUST be initialized
		//before accessing
	//System.out.println(age);//ERROR
	age = 20;
	System.out.println(age);
	//age = "twenty";//error

	//float,double
	float marks;

	
	double amount;

	//char
	char c = 'p';
	c = '1';

	//boolean
	boolean result;
	result = true;
	result = false;
	
	
	}
}