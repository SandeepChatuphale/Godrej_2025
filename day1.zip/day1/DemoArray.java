public class DemoArray{
	public static void main(String[] args)
	{
		System.out.println(args[0]);
		
		//declaration
		int[] arr;
		//OR
		//int arr[];valid NOT recommended
		//System.out.println(arr);	//ERROR
		
		//object creation
		arr = new int[3];
		System.out.println(arr[0]);

		//initialization
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;


		for(int i = 0 ; i<arr.length;i++)
			System.out.println("Element value is " + arr[i]);


		//enhanced for loop
		//added in JDK 5
		//use when we want to iterate over each element of the array sequentially
		for(int i : arr)
			System.out.println("Element value is " + i);
		
		int[] marks = new int[3];
		
		//initialization
		marks[0] = 100;
		marks[1] = 90;
		marks[2] = 78;


		int[] scores = {88,99,77};
	
	}
}