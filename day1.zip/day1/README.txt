javac -version
java -version


javac <nameoffile>.java		//compile java code

java <nameofclasswhichcontainsmainmethod>			//execute java code

keyword - pre-defined word
	  50+

identifier - user defined name given to 
		variable,class,method etc

rules for identifier
=======================
can't be a keyword
can't start with digit
can't contain special characters (+,-,&,)
can contain (a-z,A-z,_,$,digits)

e.g. a1,this_is_name
     1a,a b,

rules for file declaration
===========================
a file can contain any number of non-public classes,interfaces,enums
file name MUST match public classname in the file










    
Convention (guidelines, best practices)
===========================
class:-
1) class name should be noun
2) first letter of each word is in uppercase
e.g. Student,Employee

method:
=========================
1) method name should be verb/verb+noun
2) first letter of first word should be in small case
3) second word onwards first letter should be in uppercase
e.g. display,show,calculateSalary

variable
============================
1) small ,meaningful
2) first letter of first word should be in small case
3) second word onwards first letter should be in uppercase

empId,salary,name etc















