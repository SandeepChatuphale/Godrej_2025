public class DemoConditionalStatements{
	public static void main(String[] args)
	{
		int age = 10;
		char n = 'I';
		
		if(age >= 18){
			if(n == 'I')
				System.out.println("Eligible for voting");
		}

		int num = 1;

		if(num==1)
		{
		}
		else if(num==2)
		{
		}
		else if(num==3)
		{
		}
		else
		{
		}
		

		if(age > 18)
		{
			System.out.println("Yes");
		}
		//System.out.println("OK");//ERROR
		else{
			System.out.println("NO");
		}

		int i = 5;
		if(i > 6)
			if(i > 7){
				System.out.println("OK");
				System.out.println("OK");
			}
			else
				System.out.println("NOT OK");


		















	}
}