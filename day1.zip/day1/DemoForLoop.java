public class DemoForLoop{
	public static void main(String[] args)
	{
		//basic for loop
		for(int i = 1;i<=5;i++){
			int k = 10;	//local to for 
			System.out.println(i);
		}
		//System.out.println(k);	//ERROR

		//basic for loop
		int j = 1;
		for(;j<=5;j++)
			System.out.println(j);

		for(;j<=5;){
			System.out.println(j);
			j++;
		}
		for(;;){	//infinite loop
			System.out.println(j);
			j++;
		}


		
	}
}