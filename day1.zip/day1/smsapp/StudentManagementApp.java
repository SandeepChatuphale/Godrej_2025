import java.util.Scanner;

public class StudentManagementApp{
	public static void main(String[] args)
	{
		//create Object of Student
		//syntax:- className referenceName = new className();
		//Student s1 = new Student();
		Student s1;
		//====s1
		s1 = new Student();
		/*
		System.out.println(s1);
		System.out.println(s1.rollNumber);	//membership operator
		System.out.println(s1.name);
		*/
		/*
			s1.rollNumber = 10;
			s1.name = "Amit";
		
		s1.initialize();	//method call
		s1.display();
		*/


		String menu = """
			1) register new student
			2) Show All Students
			-1) Exit
		""";

		Scanner sc = new Scanner(System.in);
		int choice = 1;
		do{
			System.out.println(menu);
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice){
				case 1:
					Student s2 = new Student();
					
					s2.accept(1,"Amit");
					System.out.println("Registration Success");
					break;
				case 2:
					System.out.println("All Students");
					break;
				case -1:
					System.out.println("Thank you visit again");
			}
		}while(choice != -1);







	}
}