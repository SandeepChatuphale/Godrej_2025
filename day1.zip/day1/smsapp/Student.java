//cohesion

public class Student{
	
	//instance variables
	int rollNumber;
	String name;

	//method 
	//syntax: access_specifier return_type name_of_method(arguments if any){}

	//instance method
	void initialize(){
		System.out.println("In initialize()");//ONLY for debugging
		rollNumber = 1;
		name = "Amit";
	}
	
	void accept(int r,String n){
		rollNumber = r;
		name = n;
	}
		
	void display(){
		System.out.println("In display()");//ONLY for debugging
		System.out.println(rollNumber);
		System.out.println(name);

	}
	
}