public class Demo2DArray{
	public static void main(String[] args)
	{
		int[][] marks;
		//int[]marks[];
		//int marks[][];

		marks = new int[2][2];
		System.out.println(marks[0]);
		System.out.println(marks[0][0]);
		
		marks[0][0] = 10;
		marks[0][1] = 20;
		marks[1][0] = 30;
		marks[1][1] = 40;

		for(int i = 0;i<marks.length;i++)
		{
			for(int j = 0; j< marks[i].length;j++)
				System.out.print(marks[i][j]+"   ");
			System.out.println();
		}

		for(int []row :marks)
		{
			for(int data :row)
				System.out.print(data+"  ");
			System.out.println();
		}


		int[][] scores;
		scores = new int[2][];
		System.out.println(scores);
		System.out.println(scores[0]);
		System.out.println(scores[1]);




	}
}
