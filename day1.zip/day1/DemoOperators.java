public class DemoOperators
{
public static void main(String[] args)
	{
		//=
		//+,/,*,%,-
		//++,--
		//+=,-=,*=,/=
		// >,<,>=,<=,==,!=
		
		//&&,||,&,|,!
		//?:
		int sum ;
		int num1 , num2;
		num1 = 10;
		num2 = 10;
		
		sum = num1 + num2;//20
		
		num1++;
		++num1;
		
		int num3 = num1++;
		//sop(num3)//12
		//sop(num1)//13

		int num4 = ++num1;
		//sop(num4)//14
		//sop(num4)//14


		int a;
		//float a;//ERROR

		
		num4 = num4 + 10;
		
		num4 += 10;

		System.out.println(num2 = 50);
		System.out.println(num2 == 50);


		
	}
}