package com.godrejcapital.smsapp.dao.impl;

import com.godrejcapital.jpa.annotation.Entity;
import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;

import java.util.List;
import java.util.Optional;

/**
this is DAO class

 @author sandeep
 @since 1.0
 @version 1.0

 */
public class StudentDaoImpl implements StudentDao {

    private Student[] students;

    public StudentDaoImpl(){
        this.students = new Student[2];
    }

    public  StudentDaoImpl(int size)
    {
        this.students = new Student[size];
    }

    //getter - method
    public Student[] getStudents(){
        return this.students;
    }


    public Optional<Student> findByRollNumber(int rollNumber) throws StudentNotFoundException {
        for(Student s: this.students)
        {
            if(s != null) {
                if (rollNumber == s.getRollNumber())
                    return Optional.of(s);
            }
        }
        throw new StudentNotFoundException(rollNumber);
    }

    public Student save(Student s) {

        //check if entity object we are trying store is annotated with @Entity
        //if NOT DON'T allow
        Class c = s.getClass();
        boolean result = c.isAnnotationPresent(Entity.class);
        if (result) {
            Entity en = (Entity) c.getAnnotation(Entity.class);
            System.out.println("Table name is " +  en.name());
            int index = 0;
            for (Student st : this.students) {
                if (st == null) {
                    this.students[index] = s;
                    return s;
                }
                index++;
            }
            return s;
        }
        else {
            System.err.println("Student MUST be annotated with @Entity");
            return null;
        }
    }

    @Override
    public List<Student> findAll() {
        return List.of(this.students);
    }

    @Override
    public void deleteByRollNumber(int rollNumber) throws StudentNotFoundException {

        Optional<Student> o = findByRollNumber(rollNumber);
        Student studentToBeDeleted = o.get();


    }
}
