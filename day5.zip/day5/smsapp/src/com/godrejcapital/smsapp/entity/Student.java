//cohesion
package com.godrejcapital.smsapp.entity;

import com.godrejcapital.jpa.annotation.Entity;

import java.util.Comparator;

/**
 * @author sandeep
 * @since 1.0
 * @version 2.0
 */
@Entity()
public class Student implements Comparable<Student> {

    //class variable
    private static int count;
    //instance variables

    private int rollNumber;
    private String name;
    private int score;


    //method
    //syntax: access_specifier return_type name_of_method(arguments if any){}

    static {
        System.out.println("static initialization block - executed as soon as Student class is loaded");

    }

    {
        System.out.println("instance initialization block - executed just before constructor");
        count++;
        this.rollNumber = count;
    }

    //no argument constructor
    private Student() {
        System.out.println("In no argument constructor()");//ONLY for debugging
        name = "Amit";
    }

    //parameterized constructor
    //public Student(int rollNumber,String name){
    public Student(String name, int score) {
        System.out.println("in parameterized constructor");
        this.name = name;
        this.score = score;
    }

    public static int getCount() {

        return count;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public int getRollNumber() {
        return this.rollNumber;
    }

    public String getName() {
        return this.name;
    }


    public void accept(int rollNumber, String name) {
        this.rollNumber = rollNumber;
        this.name = name;
    }

    /**
     * @throws
     * @pa
     * @
     */
    public void display() {
        System.out.println("In display()");//ONLY for debugging
        System.out.println(this.rollNumber);
        System.out.println(this.name);

    }

    public int getScore() {
        return score;
    }

    //toString() method is used to return useful information about
    //the object
    //it is built-in method we are overriding
    @Override
    public String toString() {
        return this.rollNumber + "    " + this.name;
    }


    //check meaningful object equality
    @Override
    public boolean equals(Object o) {

        System.out.println("In ================");
        //pattern matching using instanceof
        //jdk 16
        if (o instanceof Student s) {
            if (this.name.equals(s.name)) {
                return true;
            }
        }
        return false;
    }

    //used in hashing algorithms collection classes
    //to improve performance
    @Override
    public int hashCode() {
        return this.name.length();
    }

    //it is executed just before gc removes object from memory
    //it is deprecated
    //it was used to release any resource used by object
    @Override
    protected void finalize() throws Throwable {

    }

    @Override
    public int compareTo(Student o) {
        System.out.println("compareTo");
        return this.name.compareTo(o.name);
    }

}