import com.godrejcapital.smsapp.dao.impl.StudentCollectionDaoImpl;
import com.godrejcapital.smsapp.dao.impl.StudentDaoImpl;
import com.godrejcapital.smsapp.entity.Address;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.util.StudentComparisonByAscScore;
import com.godrejcapital.smsapp.view.impl.StudentViewImpl;
import com.godrejcapital.smsapp.view.util.MessageType;


import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
//import java.lang.*;	//already present

public class StudentManagementApp{

	public static void main(String[] args)
	{
		//create Object of Student
		//syntax:- className referenceName = new className();
		//Student s1 = new Student();

		//initialization
		StudentViewImpl view = new StudentViewImpl();
		StudentCollectionDaoImpl dao = new StudentCollectionDaoImpl();
		Scanner sc = new Scanner(System.in);

		System.out.println("number of registrations are " + Student.getCount());

		int choice = 1;
		do{
			view.showMenu();
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice){
				case 1:
					Address addr = new Address("Mumbai",40001);
					Student s = new Student("Amit",10);

					//null
					dao.save(s);
					view.showMessage("Registration Success");
					break;
				case 2:
					List<Student> allStudents = dao.findAll();
					for(Student st : allStudents){
						st.display();
					}
					view.showMessage("All Students");
					break;
				case 3:
                    Optional<Student> o = null;
                    try {
                        o = dao.findByRollNumber(1);
						if(o.isPresent())
							//view.showMessage("Student found");
							System.out.println(o.get());

					} catch (StudentNotFoundException e) {

						view.showMessage(e.toString(), MessageType.ERROR);
                    	e.printStackTrace();
					}
					break;
				case 4:
					view.showMessage("Enter the roll number");
					int rollNUmber = sc.nextInt();
                    try {
                        dao.deleteByRollNumber(rollNUmber);
                    } catch (StudentNotFoundException e) {
                        view.showMessage(e.toString(),MessageType.ERROR);
                    }
                    break;
				case 5:
					List<Student> students = dao.findAll();
					Collections.sort(students);
					System.out.println(students);
					break;
				case 6:
					students = dao.findAll();
					Collections.sort(students,new StudentComparisonByAscScore());
					System.out.println(students);
					break;

				case -1:
					view.showMessage("Thank you visit again");
			}
		}while(choice != -1);


		System.out.println(true);






	}
}