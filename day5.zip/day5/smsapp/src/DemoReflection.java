import com.godrejcapital.smsapp.entity.Student;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class DemoReflection {
    public static void main(String[] args) throws ClassNotFoundException {

        Student s = new Student("",0);
        //Class c = Class.forName("com.godrejcapital.smsapp.entity.Student");
        Class c = s.getClass();
        System.out.println(c.getName());
        System.out.println(c.getSimpleName());
        System.out.println(c.getSuperclass());

        //Class c = Class.forName("java.lang.String");

        Method[] methods = c.getDeclaredMethods();
        System.out.println(methods.length);

        for(Method m : methods)
        {
            System.out.println(m.getName() +"   "+m.getReturnType() + "  "+ Modifier.toString(m.getModifiers()));

        }

        Field[] fields = c.getDeclaredFields();





    }
}
