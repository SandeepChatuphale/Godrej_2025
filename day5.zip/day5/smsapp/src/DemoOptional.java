import java.util.Optional;

public class DemoOptional {
    public static void main(String[] args) {
        Optional<String> o = Optional.of("Amit");

        if(o.isPresent())
        {
            String data = o.get();
            System.out.println(data);
        }

        Optional o1 = Optional.empty();
        System.out.println(o1.isPresent());
        System.out.println(o1.isEmpty());
    }
}
