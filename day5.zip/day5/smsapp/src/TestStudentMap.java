import com.godrejcapital.smsapp.entity.Student;

import java.util.HashMap;
import java.util.Map;

public class TestStudentMap {
    public static void main(String[] args) {

        Map<Student,String> m = new HashMap<>();

        Student s1 = new Student("amit",88);
        Student s2 = new Student("ajay",67);

        m.put(s1,"fresher");
        m.put(s2,"repeater");

        System.out.println(m.size());
    }
}
