import com.godrejcapital.smsapp.view.util.MessageType;

public class Main {
    public static void main(String[] args) {

       MessageType m =  MessageType.ERROR;
        System.out.println(m);
    }
}