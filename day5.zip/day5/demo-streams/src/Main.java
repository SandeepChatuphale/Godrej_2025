import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream; //added in jdk 8

public class Main {
    public static void main(String[] args) {

        List<String> cities = new ArrayList<>();
        cities.add("mumbai");
        cities.add("Pune");
        cities.add("Delhi");
        cities.add("Kochi");

        //cities.forEach(city -> System.out.println(city));

        //print cities starting with name "P"

        Stream<String> s = cities.stream(); //step-1

        Stream<String> filteredStream = s.filter(city -> city.startsWith("P"));

       // filteredStream.forEach(city -> System.out.println(city));


        cities.stream()
                .filter(city -> city.startsWith("P"))//lambda for Predicate
                .filter(city -> city.contains("n"))
                .forEach(city -> System.out.println(city));//lambda for Consumer

        //count of all cities starting with name "P"
        long count = cities.stream()
                .filter(city -> city.startsWith("P"))//lambda for Predicate
                .count();

        //new list containing starting with name "P"
        List<String> newCities = cities.stream()
                .filter(city -> city.startsWith("P"))//lambda for Predicate
                .toList();

        //new list containing length of each city
        cities.stream()
                .map(city -> city.length())
                .toList();



    }
}