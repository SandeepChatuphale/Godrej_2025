import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class DemoVector {
    public static void main(String[] args) {
        List l = new Vector();

        System.out.println(l);
        l.add(1);
        l.add("Pune");
        l.add(1,"Delhi");
        System.out.println(l);
        System.out.println(l.size());
        l.set(2,"Bombay");
        System.out.println(l);
        l.add(45);
        System.out.println(l);
        System.out.println(l.get(0));
        System.out.println(l.isEmpty());
        l.remove(1);
        System.out.println(l);
        System.out.println(l.contains("Delhi"));

        System.out.println(l.indexOf("Bombay"));
        l.clear();
        System.out.println(l);


    }
}
