import java.util.HashSet;
import java.util.Set;

public class DemoHashSet {
    public static void main(String[] args) {
        Set<String> s = new HashSet<>();
        s.add("mumbai");
        s.add("pune");
        s.add("delhi");
        System.out.println(s.size());
        System.out.println(s.isEmpty());
        System.out.println(s.contains("mumbai"));
        System.out.println(s);
        s.add("pune");//duplicates are NOT allowed
        System.out.println(s);
        s.remove("pune");
        s.clear();
    }
}
