import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class DemoTreeSet {
    public static void main(String[] args) {
        Set<String> s = new TreeSet<String>();
        s.add("mumbai");
        s.add("pune");
        s.add("delhi");
        System.out.println(s.size());
        System.out.println(s.isEmpty());
        System.out.println(s.contains("mumbai"));
        System.out.println(s);
        s.add("pune");//duplicates are NOT allowed
        System.out.println(s);
        s.remove("pune");
        s.clear();
    }
}
