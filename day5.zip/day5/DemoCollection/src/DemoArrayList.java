import java.util.*;

public class DemoArrayList {
    public static void main(String[] args) {
        ArrayList<String> l = new ArrayList<String>();

        System.out.println(l);
        l.add("Banglore");
        l.add("Pune");
        l.add(1,"Delhi");
        System.out.println(l);
        System.out.println(l.size());
        l.set(2,"Bombay");
        System.out.println(l);
       // l.add(45);
        System.out.println(l);
        System.out.println(l.get(0));
        System.out.println(l.isEmpty());
        l.remove(1);
        System.out.println(l);
        System.out.println(l.contains("Delhi"));

        System.out.println(l.indexOf("Bombay"));
        //l.clear();
        System.out.println(l);

        Collections.sort(l);//

        System.out.println(l);



        


        //ListIterator//
        Iterator<String> i =  l.iterator();

        while (i.hasNext())
        {
            String data = i.next();

            System.out.println(data);

            i.remove();

        }






    }










}
