import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DemoHashMap {
    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {

        Map<String,Integer> m = new HashMap<>();
        m.put("mumbai",22);
        m.put("delhi",11);
        m.put("nagpur",33);
        System.out.println(m);
        System.out.println(m.get("delhi"));
        System.out.println(m.isEmpty());
        System.out.println(m.size());
        System.out.println(m.containsKey("mumbai"));
        System.out.println(m.containsValue(22));
        m.put("delhi",12);
        m.clear();
        System.out.println(m);

        ArrayList<String> list = new ArrayList<>();
        list.add("Hello"); // triggers internal array allocation

        Field field = ArrayList.class.getDeclaredField("elementData");
        field.setAccessible(true);
        Object[] internalArray = (Object[]) field.get(list);

        System.out.println("Internal capacity: " + internalArray.length); // typically 10

    }
}
