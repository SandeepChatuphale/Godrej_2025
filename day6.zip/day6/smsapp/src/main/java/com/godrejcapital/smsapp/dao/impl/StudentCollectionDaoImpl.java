package com.godrejcapital.smsapp.dao.impl;

import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Repository
public class StudentCollectionDaoImpl implements StudentDao {

    private List<Student> students;

    public StudentCollectionDaoImpl(){
        this.students = new ArrayList<Student>();
    }

    @Override
    public Student[] getStudents() {
        return this.students.toArray(new Student[students.size()]);
    }

    @Override
    public Optional<Student> findByRollNumber(int rollNumber) throws StudentNotFoundException{
        for(Student s : this.students)
        {
            if(s != null && s.getRollNumber() == rollNumber) {
                Optional<Student> os =  Optional.of(s);
                return os;
            }
        }
        throw new StudentNotFoundException(rollNumber);
    }

    @Override
    public Student save(Student s) {
        this.students.add(s);
        return s;
    }

    @Override
    public List<Student> findAll() {
        return this.students;
    }

    @Override
    public void deleteByRollNumber(int rollNumber) throws StudentNotFoundException {

        Optional<Student> o = findByRollNumber(rollNumber);
        Student studentToBeDeleted = o.get();

        //creating a copy
        Student s = new Student(0,studentToBeDeleted.getName(),10);
        s.setRollNumber(studentToBeDeleted.getRollNumber());

        this.students.remove(s);

    }
}
