package com.godrejcapital.smsapp;
import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.util.StudentComparisonByAscScore;
import com.godrejcapital.smsapp.view.impl.StudentViewImpl;
import com.godrejcapital.smsapp.view.util.MessageType;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;


import java.util.*;

//import java.lang.*;	//already present
@SpringBootApplication
public class StudentManagementApp{

	public static void main(String[] args)
	{
		ApplicationContext container = SpringApplication.run(StudentManagementApp.class);
		//initialization
		StudentViewImpl view = container.getBean(StudentViewImpl.class);
		StudentDao dao = container.getBean(StudentDao.class);
		RestTemplate rt = new RestTemplate();

		Scanner sc = new Scanner(System.in);

		System.out.println("number of registrations are " + Student.getCount());

		int choice = 1;
		do{
			view.showMenu();
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice){
				case 1:
					Student s = new Student(0,"Amit",10);
					HttpEntity<Student> entity = new HttpEntity<>(s);
					rt.postForObject("http://localhost:8080/student",entity,Student.class);
					//null
					//dao.save(s);
					view.showMessage("Registration Success");
					break;
				case 2:

					Student[] sArr = rt.getForObject("http://localhost:8080/students",
							Student[].class);

					List<Student> allStudents = Arrays.asList(sArr);

					for(Student st : allStudents){
						st.display();
					}
					view.showMessage("All Students");
					break;
				case 3:


					try {
						Student foundStudent = rt.getForObject("http://localhost:8080/student/100", Student.class);
						foundStudent.display();
					} catch (HttpClientErrorException e) {
						if(e.getStatusCode() == HttpStatus.NOT_FOUND)
							view.showMessage(e.toString(),MessageType.ERROR);
					}

					/*
                    Optional<Student> o = null;
                    try {
                        //o = dao.findByRollNumber(1);

						if(o.isPresent())
							//view.showMessage("Student found");
							System.out.println(o.get());

					} catch (StudentNotFoundException e) {

						view.showMessage(e.toString(), MessageType.ERROR);
                    	e.printStackTrace();
					}*/
					break;
				case 4:
					view.showMessage("Enter the roll number");
					int rollNUmber = sc.nextInt();
                    try {
                        dao.deleteByRollNumber(rollNUmber);
                    } catch (StudentNotFoundException e) {
                        view.showMessage(e.toString(),MessageType.ERROR);
                    }
                    break;
				case 5:
					sArr = rt.getForObject("http://localhost:8080/students?sort",
							Student[].class);
					List<Student> students = Arrays.asList(sArr);
					//Collections.sort(students);
					System.out.println(students);
					break;
				case 6:
					sArr = rt.getForObject("http://localhost:8080/students?sort",
							Student[].class);
					students = Arrays.asList(sArr);
					System.out.println(students);
					break;

				case -1:
					view.showMessage("Thank you visit again");
			}
		}while(choice != -1);

		System.out.println(true);

	}
}