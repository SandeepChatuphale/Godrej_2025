package com.godrejcapital.smsapp.dao.impl;

import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;

import java.util.List;
import java.util.Optional;

public class StudentJpaDaoImpl implements StudentDao {
    @Override
    public Student[] getStudents() {
        return new Student[0];
    }

    @Override
    public Optional<Student> findByRollNumber(int rollNumber) throws StudentNotFoundException {
        return Optional.empty();
    }

    @Override
    public Student save(Student s) {
        return null;
    }

    @Override
    public List<Student> findAll() {
        return List.of();
    }

    @Override
    public void deleteByRollNumber(int rollNumber) throws StudentNotFoundException {

    }
}
