package com.godrejcapital.smsapp.dao;

import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;

import java.util.List;
import java.util.Optional;

public interface StudentDao {
    Student[] getStudents();
    Optional<Student> findByRollNumber(int rollNumber)throws StudentNotFoundException;
    Student save(Student s);
    List<Student> findAll();
    void deleteByRollNumber(int rollNumber) throws StudentNotFoundException;

}
