//cohesion
package com.godrejcapital.smsapp.entity;

import lombok.*;

/**
 * @author sandeep
 * @since 1.0
 * @version 2.0
 */
/*
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
*/
@Data()
@AllArgsConstructor()
@NoArgsConstructor
public class Student {

    //class variable
    private static int count;
    //instance variables

    private int rollNumber;
    private String name;
    private int score;

    public static int getCount() {
        return count;
    }

    public void display() {
        System.out.println("In display()");//ONLY for debugging
        System.out.println(this.rollNumber);
        System.out.println(this.name);
    }

}