package com.godrejcapital.smsapp.exception;

public class StudentNotFoundException extends Exception{

    public StudentNotFoundException(int rollNumber) {
        super(" Student with rollNumber  " + rollNumber + " is NOT present");

    }
}
