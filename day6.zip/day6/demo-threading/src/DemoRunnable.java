public class DemoRunnable {
    public static void main(String[] args) {
        //job
        EmailRunnable e = new EmailRunnable();
        SmsRunnable s = new SmsRunnable();

        //worker
        Thread emailThread = new Thread(e);
        Thread smsThread = new Thread(s);

        emailThread.start();
        smsThread.start();
    }
}
