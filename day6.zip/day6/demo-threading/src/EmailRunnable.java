public class EmailRunnable implements Runnable{
    @Override
    public void run() {
        System.out.println("Sending email");
    }
}
