public class SmsRunnable implements Runnable{
    @Override
    public void run() {
        System.out.println("Sending sms");
    }
}
