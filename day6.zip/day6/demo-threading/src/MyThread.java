public class MyThread extends Thread{
    MyThread(String name){
        super(name);
    }
    @Override
    public void run() {
       // System.out.println("In run() " + getName());
       if(getName().equals("email")){
           System.out.println("sent email");
       }
       else {
           System.out.println("sent sms");
       }
    }
    public static void main(String[] args) {
        MyThread t = new MyThread("email");
        t.start();
        MyThread t1 = new MyThread("sms");
        t1.start();
        System.out.println("in main()");
    }
}
