//cohesion
package com.godrejcapital.smsapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

/**
 * @author sandeep
 * @since 1.0
 * @version 2.0
 */
/*
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
*/
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student implements Comparable<Student> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int rollNumber;
    private String name;
    private int score;

    public void display() {
        System.out.println("In display()");//ONLY for debugging
        System.out.println(this.rollNumber);
        System.out.println(this.name);

    }

    @Override
    public int compareTo(Student o) {
        System.out.println("compareTo");
        return this.name.compareTo(o.name);
    }

}