package com.godrejcapital.smsapp.service;

public interface EmailService {

    void sendEmail();
}
