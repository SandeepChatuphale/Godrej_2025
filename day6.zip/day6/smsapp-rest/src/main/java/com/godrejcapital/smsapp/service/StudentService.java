package com.godrejcapital.smsapp.service;

import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;

import java.util.List;

public interface StudentService {
    Student searchByRollNumber(int rollNumber) throws StudentNotFoundException;
    List<Student> searchAll();
    Student registerStudent(Student s);
    void deleteStudent(int rollNumber);
}
