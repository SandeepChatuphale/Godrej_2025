package com.godrejcapital.smsapp.service.impl;

import com.godrejcapital.smsapp.service.EmailService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Async
@Service
public class EmailServiceImpl implements EmailService {
    @Override
    public void sendEmail() {

        System.out.println("sending email===============>");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Email Sent " + Thread.currentThread().getName());
        return;
    }
}
