package com.godrejcapital.smsapp.service.impl;

import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.service.EmailService;
import com.godrejcapital.smsapp.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao dao;

    @Autowired
    private EmailService service;

    @Override
    public Student searchByRollNumber(int rollNumber) throws StudentNotFoundException {
        Optional<Student> o = this.dao.findById(rollNumber);
        if(o.isPresent())
            return o.get();
        throw new StudentNotFoundException(rollNumber);
    }

    @Override
    public List<Student> searchAll() {
        return this.dao.findAll();
    }

    @Override
    public Student registerStudent(Student s) {
        this.service.sendEmail();

        return this.dao.save(s);
    }

    @Override
    public void deleteStudent(int rollNumber) {
        this.dao.deleteById(rollNumber);
    }
}
