package com.godrejcapital.smsapp;
import com.godrejcapital.smsapp.dao.StudentDao;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.exception.StudentNotFoundException;
import com.godrejcapital.smsapp.util.StudentComparisonByAscScore;
import com.godrejcapital.smsapp.view.impl.StudentViewImpl;
import com.godrejcapital.smsapp.view.util.MessageType;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;


import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
//import java.lang.*;	//already present
@SpringBootApplication
@EnableAsync
public class StudentManagementApp{

	public static void main(String[] args)
	{

		ApplicationContext container = SpringApplication.run(StudentManagementApp.class);





	}
}