import java.util.concurrent.*;

public class MainThreadpool {
    public static void main(String[] args) {
        //this is shared resource
        Resource r = new Resource();
        IncrementCallble i = new IncrementCallble(r);

        //workers
        //multiple threads working on same resource


        ExecutorService service = Executors.newFixedThreadPool(2);
        Future<Boolean> f = service.submit(i);
        try {
            Boolean result = f.get();
            System.out.println(result);
        } catch (InterruptedException e) {

        } catch (ExecutionException e) {
        }

        service.shutdown();//MUST be called -

    }
}
