public class Main {
    public static void main(String[] args) throws InterruptedException {

        //this is shared resource
        Resource r = new Resource();

        // job
        IncrementRunnable i = new IncrementRunnable(r);

        //workers
        //multiple threads working on same resource
        Thread t1 = new Thread(i);
        Thread t2 = new Thread(i);
        t1.start();
        t2.start();

        Thread.sleep(2000);
        System.out.println("Final result " + r.getData());



    }
}
