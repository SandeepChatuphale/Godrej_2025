import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class DemoCompletableFuture {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<String> c = CompletableFuture
                        .supplyAsync(()-> {
                            System.out.println(Thread.currentThread().getName());
                            return "executed by completable future";
                        });
                       String result = c.get();
        System.out.println(result);

        CompletableFuture.runAsync(()-> System.out.println("In runAsync")).get();

        TreeMap<String, Integer> map = new TreeMap<>();
        map.put("three", 3);
        map.put("3", 3);
        map.put("THREE", 3);
        System.out.println(map);

    }
}
