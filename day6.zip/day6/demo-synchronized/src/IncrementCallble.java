import java.util.concurrent.Callable;

public class IncrementCallble implements Callable<Boolean> {
    private Resource r;

    public IncrementCallble(Resource r) {
        this.r = r;
    }
    @Override
    public Boolean call() throws Exception {
        for(int i = 1;i<=10;i++){
            r.increment();
        }
        return true;
    }
}
