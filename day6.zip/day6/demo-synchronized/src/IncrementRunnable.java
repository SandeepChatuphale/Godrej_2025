public class IncrementRunnable implements Runnable{

    private Resource r;

    public IncrementRunnable(Resource r) {
        this.r = r;
    }

    @Override
    public void run() {
        for(int i = 1;i<=10;i++){
            try {
                r.increment();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
