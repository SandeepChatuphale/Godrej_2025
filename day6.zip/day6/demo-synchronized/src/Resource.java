import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Resource {

    private Lock l = new ReentrantLock();
    private int data;


    //this is some important operation which might take coule of secs
    public void increment() throws InterruptedException {

        //=====

        //l.lock();
        //boolean isAcquired = l.tryLock();
        boolean isAcquired = l.tryLock(5, TimeUnit.SECONDS);

        if(isAcquired) {
            //this is critical operation needs to be accessed by only one thread
            //at a time
            data = data + 1;
            l.unlock();
        }
        else {

        }



    }

    public int getData(){
        return this.data;
    }
}
