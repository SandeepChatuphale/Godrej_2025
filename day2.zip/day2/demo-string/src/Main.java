public class Main {
    public static void main(String[] args) {

        String sss = new String();
        System.out.println(sss);
        String s = new String("Godrej");
        System.out.println(s.length());
        System.out.println(s.toLowerCase());
        System.out.println(s.toUpperCase());
        System.out.println(s.substring(2));
        System.out.println(s.substring(1,3));
        System.out.println(s.charAt(2));
        System.out.println(s);
        System.out.println(s.concat(" india"));
        System.out.println(s);

        String s1 = "india";


        //
        StringBuffer sb = new StringBuffer("Godrej");
        sb.reverse();
        System.out.println(sb);
        System.out.println(sb.length());
        sb.append(67);
        sb.delete(1,4);

        String ss = sb.toString();

        StringBuilder ssb = new StringBuilder();
        ssb.reverse();
        System.out.println(ssb);
        System.out.println(ssb.length());
        ssb.append(67);
        ssb.delete(1,4);






    }
}