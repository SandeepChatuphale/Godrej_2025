//cohesion
package com.godrejcapital.smsapp.entity;
public class Student{

    //class variable
    private static int count;
    //instance variables
    private int rollNumber;
    private String name;

    //has-a relationship ()
    private Address addr;

    //method
    //syntax: access_specifier return_type name_of_method(arguments if any){}

    static {
        System.out.println("static initialization block - executed as soon as Student class is loaded");

    }

    {
        System.out.println("instance initialization block - executed just before constructor");
        count++;
        this.rollNumber = count;
    }

    //no argument constructor
    public Student(){
        System.out.println("In no argument constructor()");//ONLY for debugging
        name = "Amit";
    }

    //parameterized constructor
    //public Student(int rollNumber,String name){
    public Student(String name,Address addr){
        System.out.println("in parameterized constructor");
        this.name = name;
        this.addr = addr;
    }

    public static int getCount(){

        return count;
    }

    public int getRollNumber()
    {
        return this.rollNumber;
    }

    public String getName()
    {
        return this.name;
    }

    public Address getAddr() {
        return addr;
    }

    public void accept(int rollNumber, String name){
        this.rollNumber = rollNumber;
        this.name = name;
    }

   public void display(){
        System.out.println("In display()");//ONLY for debugging
        System.out.println(this.rollNumber);
        System.out.println(this.name);

    }

}