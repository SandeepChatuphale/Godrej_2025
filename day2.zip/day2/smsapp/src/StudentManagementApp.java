import com.godrejcapital.smsapp.dao.impl.StudentDaoImpl;
import com.godrejcapital.smsapp.entity.Address;
import com.godrejcapital.smsapp.entity.Student;
import com.godrejcapital.smsapp.view.impl.StudentViewImpl;
import com.godrejcapital.smsapp.view.util.MessageType;


import java.util.Scanner;
//import java.lang.*;	//already present

public class StudentManagementApp{

	public static void main(String[] args)
	{
		//create Object of Student
		//syntax:- className referenceName = new className();
		//Student s1 = new Student();

		//initialization
		StudentViewImpl view = new StudentViewImpl();
		StudentDaoImpl dao = new StudentDaoImpl();
		Scanner sc = new Scanner(System.in);

		System.out.println("number of registrations are " + Student.getCount());

		int choice = 1;
		do{
			view.showMenu();
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice){
				case 1:
					Address addr = new Address("Mumbai",40001);
					Student s = new Student("Amit",addr);
					System.out.println(s.getAddr());	//null
					dao.save(s);
					view.showMessage("Registration Success");
					break;
				case 2:
					Student[] allStudents = dao.getStudents();
					for(Student st : allStudents){
					st.display();
								}
					view.showMessage("All Students");
					break;
				case 3:
					Student foundStudent =  dao.findByRollNumber(1);
					if(foundStudent != null)
						view.showMessage("Student found");
					else
						view.showMessage("Student NOT found", MessageType.ERROR);
					break;
				case 4:



				case -1:
					view.showMessage("Thank you visit again");
			}
		}while(choice != -1);


		System.out.println(true);


		int i = 42;
		String s = (i<40)?"life":(i>50)?"universe":"everything";
		System.out.println(s);






	}
}