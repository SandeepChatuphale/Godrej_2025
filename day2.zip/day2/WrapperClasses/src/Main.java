public class Main {
    public static void main(String[] args) {

        //byte        Byte
        //short       Short
        //int             Integer
        //long          Long

        //float       Float
        //double          Double

        //char           Character
        //boolean       Boolean


        //Integer iobj = new Integer("89");
        int a = 9;
        Integer iobj = a; //auto-boxing

        a = iobj;//auto-unboxing

        String str =iobj.toString();//wrapper to string
        int i = Integer.parseInt("89");//string to primitive



    }
}