import com.godrejcapital.geometryapp.entity.Circle;
import com.godrejcapital.geometryapp.entity.Rectangle;
import com.godrejcapital.geometryapp.entity.Shape;
import com.godrejcapital.geometryapp.util.ShapeUtil;

public class GeometryApplication {

    public static void main(String[] args) {

        Circle c = new Circle("red",5);
        c.calculateArea();

        Rectangle r= new Rectangle("red",5,5);

        Shape s = c; //up-casting
                    //it is implicit
        //s = new Shape(); //ERROR
        s.draw();
        ShapeUtil.drawShape(c);

        ShapeUtil.drawShape(r);
    }
}
