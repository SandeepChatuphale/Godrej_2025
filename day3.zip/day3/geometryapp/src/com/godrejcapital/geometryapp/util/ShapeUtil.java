package com.godrejcapital.geometryapp.util;

import com.godrejcapital.geometryapp.entity.Circle;
import com.godrejcapital.geometryapp.entity.Shape;

public class ShapeUtil {

    //this method should be responsible for drawing any shape
    //passed to it as an argument
    public static void drawShape(Shape s)
    {
        s.draw();

        //circle specific method ONLY if I know s is referring to Circle Object
        if(s instanceof  Circle)
        {
            Circle c = (Circle)s;   //down-casting
                                    //it explicit
                                    //it is risky hence we use instanceof check
            c.circleSpecificMethod();
        }
    }

}
