package com.godrejcapital.geometryapp.entity;

public class Circle extends Shape {

    private int radius;

    public Circle(String color, int radius) {
        super(color);
        System.out.println("In Circle");
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    @Override   //annotation
    public void draw()
    {
        System.out.println("Circle drawn using " + color);
    }


    public void calculateArea()
    {
        System.out.println("PI * r * r");
    }

    public void circleSpecificMethod()
    {
    }


}
