package com.godrejcapital.geometryapp.entity;

public abstract class Shape {

    protected String color;

    public Shape(String color) {
        System.out.println("In Shape");
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public abstract void draw();



}
