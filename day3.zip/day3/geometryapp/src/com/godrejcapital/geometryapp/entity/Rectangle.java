package com.godrejcapital.geometryapp.entity;

public class Rectangle extends  Shape{

    private int l;
    private int b;

    public Rectangle(String color, int l, int b) {
        super(color);
        this.l = l;
        this.b = b;
    }

    public int getL() {
        return l;
    }

    public void setL(int l) {
        this.l = l;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    @Override
    public void draw() {

    }
}
