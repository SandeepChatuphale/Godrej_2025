package com.godrejcapital.smsapp.view.util;

public enum MessageType {
    SUCCESS,
    ERROR
}
