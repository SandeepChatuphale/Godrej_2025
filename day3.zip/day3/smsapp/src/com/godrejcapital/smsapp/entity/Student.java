//cohesion
package com.godrejcapital.smsapp.entity;
public class Student{

    //class variable
    private static int count;
    //instance variables
    private int rollNumber;
    private String name;

    //has-a relationship ()
    private Address addr;

    //method
    //syntax: access_specifier return_type name_of_method(arguments if any){}

    static {
        System.out.println("static initialization block - executed as soon as Student class is loaded");

    }

    {
        System.out.println("instance initialization block - executed just before constructor");
        count++;
        this.rollNumber = count;
    }

    //no argument constructor
    public Student(){
        System.out.println("In no argument constructor()");//ONLY for debugging
        name = "Amit";
    }

    //parameterized constructor
    //public Student(int rollNumber,String name){
    public Student(String name,Address addr){
        System.out.println("in parameterized constructor");
        this.name = name;
        this.addr = addr;
    }

    public static int getCount(){

        return count;
    }

    public int getRollNumber()
    {
        return this.rollNumber;
    }

    public String getName()
    {
        return this.name;
    }

    public Address getAddr() {
        return addr;
    }

    public void accept(int rollNumber, String name){
        this.rollNumber = rollNumber;
        this.name = name;
    }

    @Deprecated
   public void display(){
        System.out.println("In display()");//ONLY for debugging
        System.out.println(this.rollNumber);
        System.out.println(this.name);

    }

    //toString() method is used to return useful information about
    //the object
    //it is built-in method we are overriding
    @Override
    public String toString()
    {
        return this.rollNumber +"    "+this.name;
    }

    //check meaningful object equality
    @Override
    public boolean equals(Object o) {

        //pattern matching using instanceof
        //jdk 16
        if(o instanceof Student s){
            if (this.rollNumber == s.rollNumber) {
                return true;
            }
        }


        return false;
    }

    //used in hashing algorithms collection classes
    //to improve performance
    @Override
    public int hashCode()
    {
        return 10;
    }

    //it is executed just before gc removes object from memory
    //it is deprecated
    //it was used to release any resource used by object
    @Override
    protected void finalize() throws Throwable {

    }
}