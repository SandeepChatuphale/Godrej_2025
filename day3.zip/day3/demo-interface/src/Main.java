public class Main {
    public static void main(String[] args) {
        Printable p;
        p = new Employee();
        p.print();
        Certified c = new Employee();

    }
}