public class Employee implements Printable,Certified{
    @Override
    public void print() {
        //SIZE = 20;
    }

    public static void main(String[] args) {
        System.out.println(SIZE);
    }

    @Override
    public String getCertificate() {
        return "";
    }

    @Override
    public void printType() {

    }
}
