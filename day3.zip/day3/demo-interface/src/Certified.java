public interface Certified {


    String getCertificate();
}
