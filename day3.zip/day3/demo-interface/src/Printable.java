@FunctionalInterface
public interface Printable {

    int SIZE = 10;
    void print();
    //public void print();
   // abstract void print();
  // public abstract void print();



    //default method means implemented method
    //added in jdk 1.8
    default void printType(){}

    //static method in an interface in added in jdk 1.8
    static void of(){}

}
