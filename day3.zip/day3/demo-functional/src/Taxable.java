public interface Taxable {
    double calculateTax(double income);
}
