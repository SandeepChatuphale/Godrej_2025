public interface MyCondition {
    boolean check(String str);
}
