import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Main
{
    public static void main(String[] args) {

        int a = 10;

        //after jdk 8
        Runnable r = () -> System.out.println(); //lambda

        Taxable t1 = (double d) -> {return d* 0.10;};
        t1.calculateTax(100);

        Taxable t2 = (d) -> {return d* 0.10;};
        t2.calculateTax(100);

        Taxable t3 = d -> {return d* 0.10;};
        t3.calculateTax(100);

        Taxable t4 = d ->  d* 0.10;
        t4.calculateTax(100);

        Function<String,Integer> f ;

        Predicate<String> p;

        Consumer<String> c;

        Supplier<String> s;




    }
}