public class DemoTryCatch {
    public static void main(String[] args) {
        int a = 10;
        int b = 0;
        try {
            int r2 = 10/b;
            int result = 10/1;
            System.out.println(result);
        }
        finally {
            String s = null;
            System.out.println(s.length());
            System.out.println("ok");
        }

    }
}
