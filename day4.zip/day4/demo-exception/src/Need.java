public class Need {
    public static void main(String[] args) {

        int a = 10;
        int result = 10/0;
        System.out.println(result);

    }
}
