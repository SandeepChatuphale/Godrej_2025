package com.godrejcapital.smsapp.view.impl;


import com.godrejcapital.smsapp.view.util.MessageType;

//this is responsible for presentation logic (view)
public class StudentViewImpl {

    public void showMenu()
    {

        //text blocks - jdk 15
        String menu = """
			1) register new student
			2) Show All Students
			-1) Exit
		""";

        System.out.println(menu);
    }

    /*
    method overloading
     */
   public void showMessage(String message)
    {
        System.out.println(message);
    }

   public void showMessage(String message, MessageType type)
    {
        if(type == MessageType.SUCCESS)
            System.out.println(message);
        else
            System.err.println(message);
    }



}
